﻿namespace Homework7.Models
{
    public class ShakesPlay
    {
        public string ptitle { get; set; } = "";
        public string mainchar1 { get; set; } = "";
        public string mainchar2 { get; set; } = "";
        public string playtpe { get; set; } = "";
        public string briefdesc { get; set; } = "";
    }
}
